/*WAP in c to calculate division of a students based upon its percentage
a>90 hons
60>a>=90 1 division
45>a>=60 2 division
35>a>=45 3 division
<35 fail                                          */
#include<stdio.h>
void main()
{
    float a;
    printf("Enter your marks =  ");
    scanf("%f",&a);
    
    if(a>90)
    {
        printf("hons!!!!");
    }
    else if(a>=60 && a<90)
    {
        printf("1 division");
    }
    else if(a>=45 && a<60)
    {
        printf("2 division");
    }
    else if(a>=35 && a<45)
    {
        printf("3 division");
    }
    else 
    {
        (" fail");
    }
}


















